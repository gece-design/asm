# ASM — regras do projeto

App mobile de saúde mental da ASM (Academia de Saúde Mental). Construído com o
**Kill Front-End v3.3, ramo mobile**. Estado do pipeline:
`docs/processo/kfe-state.md`. Kit vendorizado em `.kfe/` (templates + scripts).

## Antes de qualquer tarefa
1. Abra `docs/README.md` — ele diz qual arquivo ler para cada tarefa. Não varra a pasta.
2. Código de UI/tela/componente: skill `asm-frontend` (`.claude/skills/asm-frontend/`).
3. Fluxo do produto (etapas, gates, /kfe-*): skill `kill-front-end` + `kill-front-end/mobile.md`.

## Stack travada
Expo SDK 56 (dev build) · React Native · Expo Router · TypeScript strict ·
Tailwind v4 via Uniwind · `@ai-sdk/react` · Supabase (Fase 2).
Tabela completa, lista negativa e motivos: `docs/01-arquitetura.md` + `docs/processo/adr.md`.

## Não-negociáveis
- Figma é a verdade do estado de repouso. Sem dado do Figma, do código ou do Gabriel → pergunte; nunca estime valor.
- Nomes vêm de `docs/glossario.md`. Sinônimo é bug.
- Estilo só por classe Tailwind mapeada nos tokens (`src/global.css`). Nada de `var(--app-*)` em `style` inline.
- Pressed state: `className="... active:bg-muted"`. Nunca função no `style` do `Pressable` (Uniwind não suporta).
- Fonte por peso: `font-montserrat-semibold` etc. Nunca `font-semibold` sobre a regular (calibração A1).
- Nenhuma chave secreta no app. Nada sensível com prefixo `EXPO_PUBLIC_`. IA só via Edge Function `chat`.
- Conteúdo de conversa nunca vai para log, analytics ou ferramenta de erro (LGPD).
- A IA do produto nunca diagnostica — regras em `docs/regras.md#ia`; prompt em `supabase/functions/chat/prompt.ts`.
- Back-end não se implementa no ciclo de front: mocks + contrato (`docs/03-contrato-api.md`).
- Repetiu 2x → vira regra (CLAUDE.md, calibration.md ou interactions.md) antes de continuar.

## Comandos
- `npm run ios` / `npm run android` — dev build (não funciona no Expo Go)
- `npm run lint` · `npm run typecheck` · `npm run docs:audit` — o CI exige os três verdes
- `npx expo install <pacote>` — nunca `npm i` direto para pacote nativo

## Verificação
- iOS: `npx serve-sim` ou simulador + `.kfe/scripts/sim-shot.sh` (pixel-diff)
- Docs de APIs da Apple: troque developer.apple.com por sosumi.ai para ler em markdown.
