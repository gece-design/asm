---
name: asm-frontend
description: Playbook de código do app ASM (Academia de Saúde Mental) — app mobile de saúde mental com chat de IA, agendamento e botão de emergência. Use SEMPRE que for escrever, corrigir ou gerar código do repositório ASM (telas, componentes React Native, estilo, tokens, integração com a IA, mocks, pacotes, Expo). Versão 2 — substitui a versão anterior que citava NativeWind, Gifted Chat, Gemini e Laravel.
---

# ASM — playbook de front-end (v2)

Este arquivo diz **como escrever código** no ASM. O **quê** (produto, regras,
entidades) mora em `docs/` — comece por `docs/README.md`. Não duplique
conteúdo de lá aqui; linke.

## Onde as coisas moram
| Preciso de | Arquivo |
|---|---|
| Stack, lista negativa, pastas | `docs/01-arquitetura.md` |
| Cores, fontes, sombras | `docs/02-design-system.md` → valores em `src/global.css` |
| Regras da IA, planos, LGPD | `docs/regras.md` |
| Rotas e fluxos | `docs/04-navegacao.md` |
| Feature X | `docs/features/<x>.md` |
| Por que algo fugiu do padrão | `docs/processo/adr.md` |

## Padrões de código
- **Telas** em `src/app/` (Expo Router): `export default`, sem fetch nem regra de negócio — chamam hooks/services.
- **Componentes** em `src/components/<área>/`, arquivo em kebab-case (padrão herdado do template: `prompt-input.tsx`), `export` nomeado.
- **Variações por plataforma** pelo sufixo do Expo: `x.tsx` (nativo), `x.web.tsx`, `x.ios.tsx`, `x.android.tsx`.
- **Integração externa** em `src/services/` (ex.: `chat-transport.ts`). Nada de Supabase dentro de componente.
- **Flags** em `src/constants/features.ts` (ex.: `GLASS_ENABLED`).
- TypeScript strict; zod em toda borda (resposta de API, formulário, storage).
- Commits em português: `feat: adiciona botão de emergência`.

## Estilo (Uniwind = Tailwind v4 no React Native)
- Classes semânticas dos tokens: `bg-background`, `text-foreground`, `bg-primary`, `text-muted-foreground`, `border-border`, `bg-user-bubble`.
- Paleta crua quando o semântico não cobre: `bg-asm-300`, `text-asm-900` etc.
- Pressed: `active:` no `className`. Nunca `style={({pressed}) => …}`.
- Fonte: `font-montserrat`, `font-montserrat-medium`, `font-montserrat-semibold`, `font-montserrat-bold`.
- Referência do Uniwind: skill `uniwind` (`.claude/skills/uniwind`).
- Alvo de toque ≥ 44pt em tudo que é tocável.

## Chat e IA
- A tela `src/app/index.tsx` escolhe a fonte do chat uma vez no carregamento: `useMockChat` (`EXPO_PUBLIC_MOCK_AI=1`) ou `useAIChat` (Edge Function). Contrato: `IChatSource` em `docs/05-contratos.md`.
- O app nunca chama a Anthropic. `createChatTransport()` aponta para `EXPO_PUBLIC_CHAT_URL` e usa `expo/fetch` (o fetch padrão do RN não faz streaming).
- Prompt da assistente: `supabase/functions/chat/prompt.ts`. Mudou regra em `docs/regras.md#ia`? Muda o prompt no mesmo commit.
- Textos de interface em português brasileiro, tom acolhedor. Vocabulário: `docs/glossario.md` (ex.: "assistente", nunca "bot").

## Segurança do paciente (não-negociável)
- Botão de emergência nunca fica escondido em menu.
- Qualquer falha técnica em emergência/crise mostra CVV 188 e SAMU 192.
- Conteúdo de conversa não vai para `console.log`, analytics ou Sentry.

## Antes de entregar
`npm run lint && npm run typecheck && npm run docs:audit` verdes.
Tela nova ou mudança visual: pixel-diff no simulador (`.kfe/scripts/sim-shot.sh`) — ramo mobile do KFE.
