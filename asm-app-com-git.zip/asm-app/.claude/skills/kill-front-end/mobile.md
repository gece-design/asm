# Ramo mobile — Kill Front-End (v3.3)

Contrato herdado por todas as etapas quando o produto é **app nativo**
(Expo + React Native). Irmão do `protocols.md` e do `doc-architecture.md`.
Onde este arquivo e uma skill de etapa divergirem num produto mobile, vale
este arquivo. Tudo que ele não menciona continua igual ao ramo web.

Primeiro produto a usar: ASM (Academia de Saúde Mental), 2026.

## Por que existe

No web, o Playwright renderiza e fotografa a tela real. No app, o navegador
mostra a versão **web** do React Native — outro layout (arquivos `.web.tsx`),
outro motor de fonte, outra rolagem. Medir fidelidade ali é medir a tela
errada. O ramo mobile troca os olhos do pipeline, não a disciplina.

## O que muda, etapa por etapa

| Etapa | Web (padrão) | Mobile (este ramo) |
|---|---|---|
| 1 STACKS | Vite · React · Tailwind · shadcn | Expo (dev build) · React Native · Expo Router · Tailwind via Uniwind ou NativeWind · Zustand |
| 3 INSTALL | CI: lint + build | CI: lint + typecheck + `expo export` (iOS e Android) |
| 4 MCP | Playwright MCP | Simulador iOS (`xcrun simctl`) + Maestro CLI; Playwright só p/ a versão web, se existir |
| 6 UI | screenshot Playwright | screenshot do simulador via `scripts/sim-shot.sh` |
| 8 QA | E2E Playwright · preview Vercel | E2E Maestro (`.maestro/`) · preview EAS Update (canal `preview`) |

## Padronização de render (camada 1)

A regra de ouro continua: **mesmas dimensões, mesma fonte, diff ≤ 1%**.

1. **Aparelho de referência = largura do frame.** Frame de 390 pt → iPhone
   16 (390 pt, @3x). Registre o par frame↔simulador no
   `docs/processo/figma-checklist.md`.
2. **Export do Figma na escala do aparelho** (@3x no iPhone 16), para o PNG do
   Figma e o screenshot terem exatamente os mesmos pixels (1170×2532).
3. **Status bar congelada**: `sim-shot.sh` fixa 9:41, bateria cheia e sinal
   cheio antes de fotografar. Hora diferente não pode virar "divergência".
4. **Fonte embutida no build** (plugin `expo-font` no app.json), nunca
   carregada em runtime na tela medida — elimina o flash de fallback.
5. **iOS é a plataforma de medida.** Android entra por verificação visual no
   gate e pelos fluxos Maestro; diff de pixel no Android só se o produto
   pedir (densidades fracionárias tornam o 1:1 caro demais para o ganho).

Comando: `bash <kit>/scripts/sim-shot.sh <saida.png> [deep-link]` →
depois `node <kit>/scripts/pixel-diff.js figma@3x.png saida.png`.

## Estados (camada 2)

Hover não existe no toque. A tabela de estados do mobile é:
`default · pressed · focused (teclado externo/leitor de tela) · disabled ·
loading · error · empty`. As regras I4 (foco visível), I12 (motion
reduzido — `AccessibilityInfo.isReduceMotionEnabled`) e I15 (alvo de toque
≥ 44 pt) continuam obrigatórias. Golden de estado: o fluxo Maestro leva o
componente ao estado e usa `takeScreenshot`.

## QA (etapa 8)

- Roteiros em `.maestro/<fluxo>.yaml`, derivados da spec — mesma regra do web.
- `maestro test .maestro/` roda contra o dev build no simulador.
- Preview = update EAS no canal `preview`: o humano testa no próprio celular.
  O `qa-release.md` registra o id do update no lugar da URL da Vercel.

## Pré-voo extra (etapa 4)

macOS com Xcode e simulador · `maestro --version` responde · dev build
instalado no simulador (`npx expo run:ios`) · Expo Go NÃO serve para medir
(módulos nativos e fontes diferem).
