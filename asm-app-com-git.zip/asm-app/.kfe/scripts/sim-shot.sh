#!/usr/bin/env bash
# sim-shot.sh — screenshot determinístico do simulador iOS (KFE v3.3, ramo mobile)
# Uso: bash sim-shot.sh <saida.png> [deep-link]
#   deep-link opcional (ex.: asm://agendamento) abre a tela antes da foto.
# Requer: macOS + Xcode, simulador ligado com o dev build instalado.
set -euo pipefail
OUT="${1:?Uso: sim-shot.sh <saida.png> [deep-link]}"
LINK="${2:-}"
DEV="booted"
# Status bar congelada: hora/bateria/sinal não podem virar diff.
xcrun simctl status_bar "$DEV" override --time "9:41" \
  --batteryState charged --batteryLevel 100 \
  --cellularMode active --cellularBars 4 --wifiBars 3 --dataNetwork wifi
if [[ -n "$LINK" ]]; then
  xcrun simctl openurl "$DEV" "$LINK"
fi
sleep "${SIM_SHOT_WAIT:-2}"   # tempo para animação de entrada terminar
xcrun simctl io "$DEV" screenshot --type=png "$OUT"
echo "Screenshot: $OUT"
echo "Próximo: node <kit>/scripts/pixel-diff.js <figma@3x.png> $OUT"
