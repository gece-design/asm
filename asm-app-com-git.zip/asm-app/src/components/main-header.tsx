import { Icon } from "@/components/icon";
import { Stack } from "expo-router";
import { Menu } from "lucide-react-native";
import { Pressable, Text } from "react-native";
import { useDrawer } from "./drawer-content";

/**
 * Header da tela de chat (iOS e Android).
 *
 * Herdado do template e simplificado para o ASM: sem seletor de modelo
 * (o paciente não escolhe IA) e sem o botão "Reader".
 * O lado direito fica reservado para o botão de emergência — ele entra no
 * lote de UI da feature Emergência, a partir do Figma (docs/features/emergencia.md).
 */
export function MainHeader() {
  const { openDrawer } = useDrawer();
  return (
    <>
      {process.env.EXPO_OS === "ios" ? (
        <Stack.Toolbar placement="left">
          <Stack.Toolbar.Button icon="line.3.horizontal" onPress={openDrawer} />
        </Stack.Toolbar>
      ) : (
        <Stack.Toolbar placement="left" asChild>
          <Pressable
            onPress={openDrawer}
            accessibilityLabel="Abrir menu"
            accessibilityRole="button"
            className="p-2 -ml-1 active:opacity-60"
          >
            <Icon icon={Menu} className="w-6 h-6 text-foreground" />
          </Pressable>
        </Stack.Toolbar>
      )}

      <Stack.Screen.Title asChild>
        <Text
          accessibilityRole="header"
          className="text-[17px] font-semibold text-foreground"
        >
          ASM
        </Text>
      </Stack.Screen.Title>
    </>
  );
}
