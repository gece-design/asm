/** No web a navegação fica na sidebar (sidebar.web.tsx); o header nativo não se aplica. */
export function MainHeader() {
  return null;
}
