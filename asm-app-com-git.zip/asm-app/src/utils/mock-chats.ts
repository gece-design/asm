export type MockChat = {
  id: string;
  title: string;
  daysAgo: number;
  starred: boolean;
};

export const MOCK_CHATS: MockChat[] = [
  { id: "1", title: "Ansiedade antes de reuniões", daysAgo: 5, starred: false },
  {
    id: "2",
    title: "Dificuldade para dormir",
    daysAgo: 5,
    starred: false,
  },
  {
    id: "3",
    title: "Exercício de respiração",
    daysAgo: 7,
    starred: false,
  },
  { id: "4", title: "Conversa sobre a semana", daysAgo: 7, starred: true },
  { id: "5", title: "Como lidar com a culpa", daysAgo: 7, starred: false },
  {
    id: "6",
    title: "Rotina de autocuidado",
    daysAgo: 14,
    starred: false,
  },
  {
    id: "7",
    title: "Preparar para a primeira consulta",
    daysAgo: 14,
    starred: true,
  },
  {
    id: "8",
    title: "Pensamentos acelerados à noite",
    daysAgo: 14,
    starred: false,
  },
  {
    id: "10",
    title: "Relação com o trabalho",
    daysAgo: 14,
    starred: false,
  },
  {
    id: "11",
    title: "Organizar o dia",
    daysAgo: 21,
    starred: false,
  },
  {
    id: "12",
    title: "Conversa",
    daysAgo: 28,
    starred: false,
  },
  {
    id: "13",
    title: "Conversa",
    daysAgo: 28,
    starred: false,
  },
  {
    id: "14",
    title: "Conversa",
    daysAgo: 30,
    starred: false,
  },
  {
    id: "15",
    title: "Conversa",
    daysAgo: 35,
    starred: false,
  },
];
