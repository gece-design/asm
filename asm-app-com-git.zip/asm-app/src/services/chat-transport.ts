import { DefaultChatTransport } from "ai";
import { fetch as expoFetch } from "expo/fetch";

/**
 * Transporte do chat com a IA do ASM.
 *
 * O app NÃO fala direto com a Anthropic: a chave da API mora só no servidor.
 * O destino é a Edge Function `chat` do Supabase (supabase/functions/chat),
 * que monta o prompt da Dra. Izabel, busca a base de conhecimento (RAG) e
 * faz o streaming da resposta.
 *
 * `expo/fetch` é obrigatório no nativo: o fetch padrão do React Native não
 * faz streaming.
 */
export const CHAT_URL = process.env.EXPO_PUBLIC_CHAT_URL ?? "";

export function createChatTransport() {
  return new DefaultChatTransport({
    api: CHAT_URL,
    fetch: expoFetch as unknown as typeof globalThis.fetch,
    // Enquanto não há login, vai a anon key. Com o Supabase Auth, trocar
    // pelo access_token da sessão do usuário (ver docs/03-contrato-api.md).
    headers: () => ({
      Authorization: `Bearer ${process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ?? ""}`,
    }),
  });
}
