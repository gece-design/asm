// Import de CSS com efeito colateral (global.css). O Expo gera expo-env.d.ts
// no primeiro `expo start`; isto garante o typecheck no CI antes disso.
declare module "*.css";
