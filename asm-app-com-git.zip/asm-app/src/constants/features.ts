/**
 * Feature flags do ASM.
 *
 * GLASS_ENABLED — efeito "Liquid Glass" do iOS 26 herdado do template.
 * Desligado no MVP para iOS e Android terem o mesmo visual (ADR-006).
 * Para religar: troque para `isLiquidGlassAvailable()` de "expo-glass-effect".
 */
export const GLASS_ENABLED = false;
