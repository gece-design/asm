# ASM — Academia de Saúde Mental

App mobile (iOS e Android) que une uma assistente de IA, treinada no
conhecimento da Dra. Izabel Martins, a profissionais reais — por agendamento
ou emergência.

## Rodar em 5 minutos

```bash
npm install --legacy-peer-deps
cp .env.example .env        # MOCK_AI=1 já vem ligado: não precisa de back
npm run ios                 # ou: npm run android  (dev build — Expo Go não serve)
```

## Onde está cada coisa

| Quero | Vá para |
|---|---|
| Entender o produto | `docs/00-visao-geral.md` |
| Qualquer outra coisa | `docs/README.md` (roteador) |
| Em que etapa o projeto está | `docs/processo/kfe-state.md` ou `npm run kfe:dashboard` |
| Regras para a IA que escreve código | `CLAUDE.md` |
| Back-end (Fase 2) | `supabase/README.md` |

## Qualidade

`npm run lint` · `npm run typecheck` · `npm run docs:audit` — os três rodam no
CI (`.github/workflows/kfe.yml`) junto com o bundle de iOS e Android.

Construído com o framework Kill Front-End (v3.3, ramo mobile).
Base de código derivada de software MIT — ver `THIRD_PARTY_NOTICES.md`.
