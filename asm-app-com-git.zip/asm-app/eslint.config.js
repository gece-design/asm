// https://docs.expo.dev/guides/using-eslint/
const { defineConfig } = require('eslint/config');
const expoConfig = require('eslint-config-expo/flat');

module.exports = defineConfig([
  expoConfig,
  {
    ignores: ['dist/*', 'supabase/functions/**', '.kfe/**'],
  },
  {
    // Falso positivo conhecido: as regras do React Compiler tratam
    // `sharedValue.value = x` (Reanimated, dentro de worklets e gestures)
    // como mutação proibida. Escopo restrito aos arquivos de gesto/scroll
    // herdados do template. Registro: docs/processo/adr.md (ADR-004).
    files: ['src/components/drawer-layout.tsx', 'src/components/chat/conversation.tsx'],
    rules: {
      'react-hooks/immutability': 'off',
      'react-hooks/refs': 'off',
    },
  },
]);
