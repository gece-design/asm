# .maestro/ — testes E2E (etapa 8 do KFE, ramo mobile)

Um arquivo por fluxo crítico, derivado da spec em `docs/features/` — nunca do código.
Rodar: `maestro test .maestro/` com o dev build aberto no simulador.
Primeiro roteiro previsto: `chat.yaml` (ver `docs/processo/handoff-backend.md`).
