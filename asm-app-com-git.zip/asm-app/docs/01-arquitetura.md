# Arquitetura — ASM

Produto **mobile** → segue o ramo mobile do kit
(`.claude/skills/kill-front-end/mobile.md`).
Base de código: fork do [EvanBacon/chat-template](https://github.com/EvanBacon/chat-template)
(MIT) — ver [processo/adr.md](processo/adr.md), ADR-001.

## Stack

| Camada | Escolha | Motivo (se desvio da base) |
|--------|---------|----------------------------|
| Build | Expo SDK 56 (dev build, não Expo Go) · EAS | Produto mobile — desvio aprovado do kit |
| UI | React Native 0.85 + React 19 + TypeScript strict | Produto mobile |
| Navegação | Expo Router (file-based, rotas tipadas) | Produto mobile |
| Estilo | Tailwind v4 via **Uniwind** + tokens em `src/global.css` | Veio no template; trocar por NativeWind seria retrabalho sem ganho — ADR-002 |
| Componentes | Próprios em `src/components/` (herdados do template + ASM) | shadcn/Radix não existem no nativo |
| Chat | `@ai-sdk/react` (`useChat`) + streaming via `expo/fetch` | Substitui o Gifted Chat — ADR-003 |
| Listas | `@legendapp/list` (virtualizada) | Veio no template |
| Animação | Reanimated 4 + Gesture Handler | Veio no template |
| Validação | zod nas bordas (API, forms, storage) | — |
| Estado global | Zustand (quando precisar; hoje contexto + store de streaming) | Decisão do projeto |
| Dados | mocks realistas (`EXPO_PUBLIC_MOCK_AI=1`) até a Fase 2 | — |

## Lista negativa (PROIBIDO)

- styled-components, Redux, StyleSheet solto quando existe classe Tailwind equivalente.
- `var(--app-*)` em `style` inline — use a classe mapeada (`bg-muted`, `text-foreground`).
- Função no `style` do `Pressable` — use `active:` no `className` (limitação do Uniwind).
- Chave de API (Anthropic ou `service_role` do Supabase) no app. Nada sensível com prefixo `EXPO_PUBLIC_`.
- Chamar a Anthropic direto do app — sempre pela Edge Function `chat`.
- Gifted Chat, NativeWind junto do Uniwind, Laravel, Pinecone (substituídos — ver ADRs).
- Logar conteúdo de conversa (console, analytics, Sentry) — dado de saúde (LGPD).
- Qualquer lib fora desta tabela sem ADR em [processo/adr.md](processo/adr.md).

## Estrutura de pastas

```
src/
├── app/                 Expo Router — telas (default export). Sem lógica de negócio.
│   ├── _layout.tsx      providers + drawer + stack
│   ├── index.tsx        chat principal
│   ├── chats.tsx        histórico de conversas
│   └── (settings)/      configurações e perfil
├── components/          UI reutilizável (named exports)
│   ├── chat/            conversa, mensagem, campo de mensagem, streaming
│   └── markdown/        renderizador de markdown das respostas
├── constants/           flags e constantes (features.ts)
├── services/            integração externa (chat-transport.ts → Edge Function)
├── utils/               helpers puros
└── global.css           tokens (fonte: Figma via MCP)
assets/fonts/            Montserrat embutida no build
supabase/                back-end (Fase 2 — rascunho, não aplicado)
.maestro/                roteiros E2E (etapa 8)
.kfe/                    kit Kill Front-End vendorizado (templates + scripts)
```

NÃO mora em `src/app/`: fetch, regra de negócio, estado global. NÃO mora em `components/`: acesso a Supabase.

## Fronteira com o back-end

Back-end **não é implementado no ciclo de front**: define-se e entrega-se pronto.

| Item | Decisão |
|------|---------|
| Stack do back | Supabase: Auth · Postgres + RLS · pgvector · Edge Functions (Deno) |
| IA | Claude Sonnet via Edge Function `chat` (modelo por secret `ASM_CHAT_MODEL`) |
| Embeddings (RAG) | `gte-small` nativo do Supabase (384 dim, sem custo extra) |
| Quem implementa | Gabriel Correa — Fase 2 do contrato (back-end) |
| Contrato | [03-contrato-api.md](03-contrato-api.md) · [api-contract.yaml](api-contract.yaml) |
| Estado hoje | 100% sobre mocks · rascunho em `supabase/` |

Mapa mock → endpoint na entrega: [processo/handoff-backend.md](processo/handoff-backend.md).
