# Contrato de API — ASM

Especificação executável: [api-contract.yaml](api-contract.yaml).
Este arquivo explica os **padrões**; o yaml lista as rotas.

Dois tipos de endpoint convivem no Supabase:
- **Tabelas via PostgREST** (`/rest/v1/...`) — CRUD simples, protegido por RLS. Segue o formato do PostgREST, não o envelope abaixo.
- **Edge Functions** (`/functions/v1/...`) — tudo que tem lógica (chat com IA, agendamento, emergência). Seguem o envelope abaixo, exceto o streaming do chat.

## Auth

Supabase Auth (JWT). Fluxo: cadastro/login → sessão → header `Authorization: Bearer <access_token>` em toda chamada. Sem sessão, só a anon key (fase de mocks).
Rotas de auth: gerenciadas pelo SDK `@supabase/supabase-js` (`signUp`, `signInWithPassword`, `signOut`, `refreshSession`).

## Envelope de resposta

```json
{ "data": <payload>, "meta": { }, "errors": [ ] }
```

| Campo | Quando aparece |
|-------|----------------|
| data | sucesso |
| meta | paginação, totais |
| errors | falha (data = null) |

**Exceção:** `POST /functions/v1/chat` responde em streaming no formato *UI Message Stream* do AI SDK (é o que o `useChat` consome). Erro antes do stream começar volta no envelope.

## Paginação

Cursor por `created_at` (listas de conversa e mensagem crescem sem fim): `?antes=<ISO>&limite=<n>`, `meta.proximo_cursor` na resposta. Limite padrão 30, máximo 100.

## Erros

| HTTP | Significado | Corpo |
|------|-------------|-------|
| 401 | não autenticado | errors[] |
| 403 | autenticado, sem permissão | errors[] |
| 405 | método inválido | errors[] |
| 422 | falha de validação | errors[] por campo |
| 429 | limite do plano atingido (ex.: mensagens do Free) | errors[] com `code: limite_plano` |

## Convenções

| Item | Decisão |
|------|---------|
| Idioma dos campos | PT, snake_case (`created_at`/`updated_at` ficam em EN por padrão do Postgres) |
| Datas | ISO-8601 UTC |
| Dinheiro | centavos inteiros (R$ 49,00 = 4900) |
| IDs | UUID |

## Regra de ouro

O front nasce sobre mocks que espelham este contrato. Quando o endpoint real
chegar, ele passa nos MESMOS testes E2E — o front não refatora, muda a origem
do dado. Protocolo completo: [processo/handoff-backend.md](processo/handoff-backend.md).
