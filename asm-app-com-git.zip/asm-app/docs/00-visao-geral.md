# Visão geral — ASM

## O que é

App de saúde mental que junta uma IA de acompanhamento diário, treinada no conhecimento da Dra. Izabel Martins, com acesso a profissionais reais por agendamento ou emergência.

## Para quem

| Perfil | Dor | O que faz aqui |
|--------|-----|----------------|
| Paciente (B2C) | Precisa de apoio emocional no dia a dia e não tem com quem falar entre as sessões — ou nem começou terapia | Conversa com a IA, agenda consulta, aciona emergência |
| Profissional da ASM | Precisa chegar à consulta sabendo o contexto do paciente | Atende consultas e plantão; recebe o relatório do paciente |
| ASM (Dra. Izabel) | A operação de consultório online não escala | Digitaliza o cuidado e vende assinatura |

## Proposta de valor

Não é um chatbot. É a ponte entre IA e cuidado humano: a IA acompanha o dia a dia, e um profissional real está sempre a um toque — por agendamento ou por emergência. Apps de IA (Wysa, Woebot, Cíngulo) não têm o profissional; plataformas de profissionais (Zenklub, Vittude) não têm IA especializada.

## Escopo v1

<!-- Dono: fw-ux (U5). Preenchido no gate forte da UX. Base: cláusula 1 do contrato. -->

| Entra na v1 | Por quê |
|-------------|---------|
| Chat com IA treinada no conhecimento da Dra. Izabel | Núcleo do produto — cláusula 1 do contrato |
| Agendamento de consultas com profissionais reais | A ponte IA → humano — cláusula 1 |
| Botão de emergência com acionamento de profissional | Segurança do paciente — cláusula 1 |
| Detecção de crise pela IA | Complementa a emergência — cronograma meses 4–5 |
| Relatório do paciente para uso na consulta | Documento-base do projeto, seção 3 |
| Design e identidade visual das telas | Cláusula 1 |
| Integração com banco de dados e APIs de IA | Cláusula 1 |

| Fica pra depois | Por quê |
|-----------------|---------|
| Gamificação (XP, exercícios, recompensas) | Fase 2 |
| Diário emocional com gráfico de humor | Fase 2 |
| Plano terapêutico interativo | Fase 2 |
| Dashboard do profissional | Fase 2 |
| Dark mode | Fase 2 |
| Painel B2B corporativo | MVP é B2C |

## NÃO-ESCOPO

- A IA não faz diagnóstico nem sugere nome de transtorno (CFP).
- A IA não substitui terapia nem se apresenta como profissional.
- O app não prescreve nem comenta medicação.
- O app não faz videochamada própria na v1 — a consulta usa link externo (a definir).
- Não há cadastro aberto de psicólogos de fora da ASM na v1 (pendência em aberto — ver [regras.md](regras.md)).
- Não há versão web pública do app; o alvo é iOS e Android.
- Nenhuma conversa é guardada sem consentimento explícito (LGPD).

## Vocabulário

Nomes canônicos: [glossario.md](glossario.md).
