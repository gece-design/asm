# Glossário — ASM

Um conceito = **um** nome. O nome daqui é o que aparece no Figma, no código,
na doc e na conversa com o cliente. Sinônimo é dívida.

Idioma decidido na etapa STACKS: PT — ver [01-arquitetura.md](01-arquitetura.md).

| Termo | Significado | Onde aparece |
|-------|-------------|--------------|
| Paciente | pessoa que usa o app para cuidar da saúde mental | [perfil](objetos/perfil.md) |
| Profissional | psicólogo(a) ou especialista real que atende pela ASM | [profissional](objetos/profissional.md) |
| Assistente | a IA do app, treinada no conhecimento da Dra. Izabel | [chat-ia](features/chat-ia.md) |
| Conversa | uma sessão de chat (paciente com a assistente ou com profissional) | [conversa](objetos/conversa.md) |
| Mensagem | uma fala dentro da conversa | [mensagem](objetos/mensagem.md) |
| Consulta | atendimento agendado com um profissional | [consulta](objetos/consulta.md) |
| Emergência | acionamento imediato de profissional pelo paciente | [emergencia](features/emergencia.md) |
| Alerta de crise | registro de risco detectado pela assistente | [alerta-crise](objetos/alerta-crise.md) |
| Plantão | escala de profissionais disponíveis para emergência | [emergencia](features/emergencia.md) |
| Base de conhecimento | conjunto de documentos da Dra. Izabel consultado pela assistente | [documento](objetos/documento.md) |
| Relatório do paciente | resumo gerado para uso na consulta | [relatorio-paciente](features/relatorio-paciente.md) |
| Acolhimento | atendimento breve de escuta (serviço avulso) | [regras](regras.md) |

## Nomes proibidos

| Não use | Use |
|---------|-----|
| Dr. Acolhe+ | ASM |
| usuário (na UI) | você / paciente |
| bot, chatbot | assistente |
| terapeuta (para a IA) | assistente |
| SOS (texto de UI) | Emergência |
