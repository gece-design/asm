# Kill Front-End — estado
Produto: ASM · Cenário: A · Modo: new-product · Ramo: mobile
Kit: v3.3 · Início: 2026-09-23 · Baseline de fidelidade: —

| # | Etapa | Status | Gate | Aprovado em |
|---|-------|--------|------|-------------|
| 1 | STACKS | concluída | humano | 2026-09-23 |
| 2 | SRS | aguardando-gate | humano | — |
| 3 | INSTALL | aguardando-gate | técnico | — |
| 4 | MCP | pendente | humano | — |
| 5 | UX | pendente | humano (forte) | — |
| 6 | UI | pendente | humano por lote | — |
| 7 | DOC | pendente | técnico | — |
| 8 | QA | pendente | humano | — |
| 9 | GITHUB | pendente | humano (final) | — |

## Lotes (modo new-screens)
| Lote | Telas/Componentes | Tempo (h) | Diff médio | Gate em |
|------|-------------------|-----------|-----------|---------|

## Exceções aprovadas
- 2026-09-23 · INSTALL executado antes do gate da SRS (base vinda do template; nenhum código de feature) · Gabriel ("manda bala")

## Log
- 2026-09-23 · STACKS aprovada: 6 decisões (Uniwind, sem Gifted Chat, IA via Edge Function, Sonnet, sem seletor de modelo, sem Liquid Glass) — ADR-001…006
- 2026-09-23 · SRS gerada a partir do documento-base e do contrato — aguarda revisão de PRD, não-escopo e regras
- 2026-10-19 · INSTALL: fork + limpeza + tokens ASM + Montserrat + KFE v3.3 (refeito após o ambiente ser zerado)
- 2026-10-19 · Kit atualizado para v3.3 (ramo mobile) — primeiro produto a usar
