# Fontes — ASM
<!-- Resolver ANTES da tela piloto. Fallback silencioso de fonte é o inimigo
     nº 1 do pixel-perfect: o olho quase não vê, o diff acusa em tudo. -->

## Inventário (do Figma)
| Família | Pesos usados | Licença ok? | Fonte do arquivo (Google/Adobe/compra) |
|---------|--------------|-------------|----------------------------------------|
| Montserrat | 400 · 500 · 600 · 700 | sim (OFL) | Google Fonts — embutida em `assets/fonts/` via plugin expo-font |
| Quagi | a confirmar no Figma | **NÃO CONFIRMADA para app** | fonte da marca — plano B: Plus Jakarta Sans (OFL) |

## Instalação no produto
- [x] Montserrat 400–700 embutida no build (app.json → expo-font) · [ ] Quagi (bloqueada pela licença)
- [x] Sem carregamento em runtime (embutida) → sem flash de fallback
- [x] Um arquivo por peso; peso escolhido pela família (`font-montserrat-semibold`), nunca sintetizado — calibração A1

## Checagem anti-fallback (obrigatória antes de cada diff)
No render de verificação, confirme via DevTools/Playwright que o
`font-family` computado é a família esperada — se o fallback do sistema
assumiu, o diff é inválido: conserte a fonte, não o componente.

## Exceções aprovadas
- <caso> · <motivo> · <aprovado por>
