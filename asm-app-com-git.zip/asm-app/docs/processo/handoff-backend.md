# Handoff back-end — ASM · rascunho 2026-10-19

## Como rodar o front em 5 minutos
clone → install → dev (detalhes no README do repo). Tudo roda sobre mocks.

## Protocolo de integração
A troca é endpoint a endpoint. O mock só morre quando o endpoint real passa
nos MESMOS testes E2E (`.maestro/`). O front não refatora — muda a origem do dado.

## Mapa mock → endpoint
| Rota (contrato) | Mock atual | Regra de negócio (docs/regras.md) | Teste E2E que valida |
|-----------------|-----------|------------------------------------|----------------------|
| `POST /functions/v1/chat` | `useMockChat` (`EXPO_PUBLIC_MOCK_AI=1`) | [IA](../regras.md#ia) | `.maestro/chat.yaml` (a criar na etapa 8) |

## Auth
Supabase Auth (JWT) · fluxo em [03-contrato-api.md](../03-contrato-api.md#auth)

## Convenções de resposta
Envelope { data, meta, errors } · paginação: cursor por created_at · idioma dos campos: PT (exceção: streaming do chat)

## Dúvidas previstas (responda antes de perguntarem)
- …
