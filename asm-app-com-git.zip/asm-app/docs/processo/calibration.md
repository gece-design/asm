# Calibração de fidelidade — ASM
Limiar de aceite: diff ≤ 1,0% · geometria zero-divergente
Parâmetros de render (ramo mobile): simulador iPhone 16 (390pt @3x) · export do Figma @3x · status bar congelada 9:41 · diff via `.kfe/scripts/pixel-diff.js` sobre `.kfe/scripts/sim-shot.sh`

<!-- Toda divergência recorrente vira regra AQUI. Releia antes de cada lote.
     2 ocorrências do mesmo desvio sem regra registrada = falha de processo. -->

## Regras de geração
| # | Situação no Figma | Regra no código | Origem (data/lote) |
|---|-------------------|-----------------|--------------------|
| G1 | line-height em px | leading-[Npx] — nunca leading-* nomeado (arredonda) | AlumyPlay |
| G2 | letter-spacing em % | tracking-[N em]: converta % → em (÷100) — nunca tracking-wide aproximado | AlumyPlay |
| G3 | Fill container / Hug | Fill → w-full ou flex-1 conforme o eixo; Hug → w-fit — nunca largura fixa "que coube" | kit |
| G4 | Sombra multi-camada | shadow-[...] custom com TODAS as camadas — nunca shadow-md "parecida" | kit |
| G5 | Cor com alpha | token/NN (ex.: bg-base/40) — nunca rgba() solto | AlumyPlay |
| G6 | Gap do auto-layout | gap-* no container — nunca margin nos filhos | kit |
| G7 | Interação hover-only | hover: sempre sob hoverOnlyWhenSupported; definir o equivalente touch na spec | AlumyPlay |
| A1 | Qualquer peso de fonte | classe `font-montserrat-<peso>` (família por peso) — nunca `font-semibold` sobre Montserrat-Regular (Android sintetiza/ignora) | ASM · INSTALL |
| A2 | Estado de hover | não existe no toque: vira `active:` (pressed) — G7 adaptada ao ramo mobile | ASM · INSTALL |

## Limitações de render aceitas (exceções permanentes)
| # | O quê | Por quê | Print | Aprovado por |
|---|-------|---------|-------|--------------|
