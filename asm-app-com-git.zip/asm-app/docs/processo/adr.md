# ADRs — ASM

## ADR-001 · Base de código: fork do EvanBacon/chat-template · 2026-09-23
Desvio: o repo não nasce vazio no INSTALL — parte do chat-template (MIT, Expo SDK 56, commit 40379fc).
Motivo: UI de chat no nível do ChatGPT (streaming, markdown, drawer, teclado) pronta; licença MIT permite uso comercial. Aviso de copyright mantido em THIRD_PARTY_NOTICES.md.
Aprovado por: Gabriel Correa

## ADR-002 · Uniwind no lugar do NativeWind · 2026-09-23
Desvio: Tailwind v4 via Uniwind, não NativeWind.
Motivo: veio no template; mesma lógica de classes, troca seria retrabalho sem ganho.
Aprovado por: Gabriel Correa

## ADR-003 · Chat do AI SDK no lugar do Gifted Chat · 2026-09-23
Desvio: sai o React Native Gifted Chat; entra `useChat` (@ai-sdk/react) com os componentes do template.
Motivo: streaming nativo e UI mais próxima do ChatGPT; Gifted Chat não faz streaming.
Aprovado por: Gabriel Correa

## ADR-004 · Regras do React Compiler desligadas em 2 arquivos · 2026-09-23
Desvio: `react-hooks/immutability` e `react-hooks/refs` off em `drawer-layout.tsx` e `chat/conversation.tsx`.
Motivo: falso positivo com `sharedValue.value` do Reanimated em worklets (código herdado do template).
Aprovado por: Gabriel Correa (INSTALL)

## ADR-005 · IA via Supabase Edge Function · 2026-09-23
Desvio: sai a rota de API do Expo (`app/api/chat+api.ts`) do template.
Motivo: back único no Supabase (auth, banco, RAG, chave protegida); sem segundo servidor para hospedar.
Aprovado por: Gabriel Correa

## ADR-006 · Liquid Glass desligado no MVP · 2026-09-23
Desvio: `GLASS_ENABLED = false` (`src/constants/features.ts`); telas de seletor de modelo, capabilities e anexos removidas.
Motivo: iOS e Android com o mesmo visual; paciente não escolhe modelo de IA; anexos fora do escopo.
Aprovado por: Gabriel Correa
