# Navegação — ASM

## Rotas

| Rota | Tela | Acesso | Feature |
|------|------|--------|---------|
| `/` | Chat principal | autenticado* | [chat-ia](features/chat-ia.md) |
| `/chats` | Histórico de conversas | autenticado* | [chat-ia](features/chat-ia.md) |
| `/(settings)/settings` | Configurações | autenticado* | [autenticacao](features/autenticacao.md) |
| `/(settings)/profile` | Perfil | autenticado* | [autenticacao](features/autenticacao.md) |
| `/entrar` · `/cadastro` | Login e cadastro | público | [autenticacao](features/autenticacao.md) — a criar |
| `/profissionais/[id]` | Detalhe do profissional | autenticado | [agendamento](features/agendamento.md) — a criar |
| `/consulta/[id]` | Confirmação da consulta | autenticado | [agendamento](features/agendamento.md) — a criar |
| `/emergencia` | Emergência | autenticado | [emergencia](features/emergencia.md) — a criar |

\* Enquanto não há login (fase de mocks), essas rotas estão abertas.

Regras de acesso por perfil: [regras.md](regras.md).

## Fluxos

<!-- Dono: fw-ux (U3). PROPOSTA a partir do documento-base — aprovar no gate forte da UX. -->

### Primeiro acesso

```mermaid
flowchart TD
  A[Abre o app] --> B{Tem sessão?}
  B -->|não| C[Onboarding] --> D[Cadastro] --> E[Consentimento LGPD]
  E --> F[Chat principal]
  B -->|sim| F
```

### Do chat à consulta

```mermaid
flowchart TD
  A[Chat com a IA] --> B{Pede ou precisa de profissional?}
  B -->|sim| C[IA mostra profissionais no chat] --> D[Detalhe do profissional]
  D --> E[Escolhe horário] --> F[Confirmação da consulta]
  B -->|não| A
```

### Emergência

```mermaid
flowchart TD
  A[Qualquer tela] --> B[Toque no botão de emergência]
  C[IA detecta risco no chat] --> D[Mensagem de acolhimento + CVV 188]
  D --> B
  B --> E{Há profissional de plantão?}
  E -->|sim| F[Conecta com o profissional]
  E -->|não| G[CVV 188 / SAMU 192 em destaque]
```

## Estados de navegação

| Situação | Comportamento |
|----------|---------------|
| Rota inexistente | tela padrão do Expo Router (`+not-found`) em PT, com volta ao chat |
| Sem permissão | redirect para o chat, sem vazar a existência da rota |
| Sessão expirada | redirect para `/entrar` preservando o destino |
