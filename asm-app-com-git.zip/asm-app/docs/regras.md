# Regras de negócio — ASM

Regras **transversais** a várias features. Regra que só vale dentro de uma
feature mora no arquivo dela, em [features/](features/). Regra que só vale
dentro de uma entidade mora em [objetos/](objetos/), como invariante.

## Acesso e perfis

| Perfil | Vê | Faz | Não pode |
|--------|----|-----|----------|
| Paciente | as próprias conversas, consultas e perfil | conversa com a IA, agenda, aciona emergência | ver dado de outro paciente |
| Profissional | agenda própria; relatório dos pacientes que atende | atende consulta e plantão | ver conversa de paciente sem consentimento |
| Admin ASM | cadastro de profissionais e base de conhecimento | cadastra profissional, alimenta a base | ler conversas de pacientes |

## Planos e cobrança

| Plano | Limites | O que libera |
|-------|---------|--------------|
| Free | chat IA limitado (limite PENDENTE) · 1 grupo/mês | atividades básicas |
| Basic — R$ 49/mês | 3 grupos/mês · 1 acolhimento | chat IA ilimitado, diário emocional (Fase 2) |
| Premium — R$ 149/mês | 4 sessões mensais | tudo do Basic + plano terapêutico, relatório, prioridade |

Avulsos: consulta R$ 150/h · acolhimento R$ 100/h · grupo R$ 50 · atividade rápida (15 min) R$ 45.
Cobrança dentro do app: fora do MVP de código até definição (loja × link externo).

## IA

- Nunca diagnostica, nunca comenta medicação, nunca se apresenta como terapeuta (CFP).
- Sinal de risco à vida → acolhe, orienta o botão de emergência e informa CVV 188 / SAMU 192 — ver [deteccao-crise](features/deteccao-crise.md).
- Responde sempre em português brasileiro, tom acolhedor e prático.
- Base de conhecimento: só conteúdo da Dra. Izabel. Sem trecho relevante, não inventa informação técnica.
- Prompt de sistema: `supabase/functions/chat/prompt.ts` — muda junto com esta seção.

## Privacidade (LGPD)

- Dado de saúde mental é dado sensível: consentimento explícito antes da primeira conversa com a IA.
- Conteúdo de conversa nunca vai para log, analytics ou ferramenta de erro.
- Chaves de API só no servidor.

## Responsabilidade técnica

Sempre há um psicólogo responsável técnico pelo app (CFP). Nome: PENDENTE.

## Estados e transições transversais

| De | Para | Quando | Quem pode |
|----|------|--------|-----------|
| conversa com IA | conversa com profissional | crise detectada ou emergência acionada | sistema / profissional de plantão |

## Exceções

| Regra | Exceção | Por quê | Aprovada por |
|-------|---------|---------|--------------|

## Pendências de negócio (decisão da Dra. Izabel)

- Cobertura do plantão de emergência (quem, qual horário). **Bloqueia o lançamento da emergência.**
- Profissionais só da ASM ou abertos a qualquer psicólogo.
- Quem acessa o relatório do paciente (só o profissional ou também o paciente).
- Limite de mensagens do plano Free.
- Como o conhecimento da Dra. Izabel será entregue (texto, áudio, material existente).
