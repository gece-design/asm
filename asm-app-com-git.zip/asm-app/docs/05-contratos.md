# Catálogo de contratos — ASM

O que uma parte do sistema promete à outra. Quem CONSOME lê aqui; quem
IMPLEMENTA linka pra cá. Assinatura mora neste arquivo e em mais nenhum.

<!-- Dono: fw-doc. Atualizado por lote, lendo o código. -->

## Contratos de dado (ports)

### `IChatSource`

```ts
type IChatSource = {
  messages: ChatMessage[];          // { id, role: "user" | "assistant", content }
  input: string;
  setInput: (v: string) => void;
  isGenerating: boolean;
  onSend: () => void;
  streamingStore: StreamingStore;   // texto parcial da resposta em curso
  error?: Error | null;
};
```

| Método | Entrada | Saída | Erros |
|--------|---------|-------|-------|
| onSend | `input` atual | nova mensagem do paciente + resposta em streaming | rede, 401, 429 (`limite_plano`) |

Implementações conhecidas: `useMockChat` e `useAIChat` em `src/app/index.tsx` (a escolha é por `EXPO_PUBLIC_MOCK_AI`).
Consumido por: [chat-ia](features/chat-ia.md).

## Contratos de componente

Props de cada componente ficam no arquivo do componente — aqui fica só o que
é **compartilhado entre componentes**.

| Contrato | O que padroniza | Quem implementa |
|----------|-----------------|-----------------|
| `Pressable` com `active:` | estado pressed via className, nunca função no `style` | todo componente tocável |
| Alvo de toque ≥ 44pt | área mínima (I15) | todo componente interativo |

Catálogo por componente: [componentes/](componentes/).

## Contratos de estado (camada 2)

Vocabulário fechado de estados e famílias: [02-design-system.md](02-design-system.md).
Declaração por componente e regras locais: [processo/interactions.md](processo/interactions.md).
Banco global herdado (I1–I15): `.kfe/interactions-global.md`.

## Como adicionar um contrato

Arquivo novo se for um domínio novo; entrada nova aqui se for uma port do
domínio existente. **Adicionar implementação não muda o contrato** — só
acrescenta uma linha na lista de implementações (OCP).
