# Design system — ASM

## Direção visual

<!-- Dono: fw-ux (U4). Proposta da IA, gosto final do humano. -->

Referências: interface estilo ChatGPT (limpa, conversa no centro) · Tom: acolhedor, calmo, humano · Personalidade: tecnologia + humanidade, muito espaço em branco.
O que este produto NUNCA parece: hospital (frio, clínico), app de meditação genérico (roxo/lilás dominante), chatbot de atendimento (balões coloridos e emojis).

Tema claro no MVP. Dark mode é Fase 2.

## Fundações

<!-- Valores de marca vindos do documento-base (paleta oficial ASM).
     O mapa semântico abaixo é PROVISÓRIO até a tela piloto (etapa 4):
     a partir dali, o Figma via MCP manda e esta tabela é corrigida. -->

### Cor
| Token | Valor | Uso |
|-------|-------|-----|
| asm-50 → `bg-background` | #F2FDFF | fundo principal |
| asm-100 → `bg-user-bubble` | #98E4EE | balão do paciente, elementos secundários |
| asm-300 → `bg-primary` | #22D5EE | CTAs, marca |
| asm-600 → `text-muted-foreground` | #127F8E | headers, ícones ativos, texto de apoio |
| asm-900 → `text-primary-foreground` | #0A4C55 | texto sobre azul, fundos escuros |
| asm-ink → `text-foreground` | #25292A | texto principal |
| roxo (premium) | PENDENTE — valor não definido | cor secundária, uso moderado |
| gradiente de marca | #22D5EE → #98E4EE | banners e destaques |

Tokens semânticos com transparência (`muted`, `border`, `secondary`, `accent`) derivam da paleta — provisórios, ver `src/global.css`.

### Tipografia
| Token | Família | Peso | Tamanho / line-height |
|-------|---------|------|------------------------|
| `font-montserrat` | Montserrat | 400 | PENDENTE — Figma |
| `font-montserrat-medium` | Montserrat | 500 | PENDENTE — Figma |
| `font-montserrat-semibold` | Montserrat | 600 | PENDENTE — Figma |
| `font-montserrat-bold` | Montserrat | 700 | PENDENTE — Figma |
| títulos de destaque | Quagi | — | PENDENTE — licença para app não confirmada; plano B: Plus Jakarta Sans |

Fontes instaladas e checagem anti-fallback: [processo/fonts-checklist.md](processo/fonts-checklist.md).

### Espaçamento e raio
| Token | Valor |
|-------|-------|
| — | PENDENTE — sai das variables do Figma na etapa 4 |

### Elevação
| Token | Sombra (x/y/blur/spread/cor/alpha) |
|-------|------------------------------------|
| shadow-card | 0/1/3/0 asm-900 6% + 0/1/2/0 asm-900 4% |
| shadow-float | 0/4/16/0 asm-900 8% + 0/1/4/0 asm-900 4% |
| shadow-composer | 0/2/8/0 asm-900 6% + anel 1px asm-900 3% |
| shadow-composer-focus | 0/4/16/0 asm-900 10% + anel 1px asm-300 35% |

### Motion
| Nome | Duração | Uso |
|------|---------|-----|
| fast | 120ms | micro-feedback (press) |
| base | 200ms | transição de estado |
| slow | 320ms | entrada/saída de superfície |

Motion reduzido do sistema é obrigatório em todo motion (regra I12).

## Famílias de componente

`acao` · `entrada` · `navegacao` · `superficie` · `feedback` · `overlay` · `midia`

Família define a regra de estado herdada. Declaração por componente:
[processo/interactions.md](processo/interactions.md). Catálogo:
[componentes/](componentes/).

## Fonte canônica

O Figma manda no estado de repouso. Divergência visual é bug do código,
medida por pixel-diff no simulador iOS — ver [processo/calibration.md](processo/calibration.md).
