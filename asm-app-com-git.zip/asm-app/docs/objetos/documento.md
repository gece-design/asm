# Objeto: Documento

## Responsabilidade

Trecho da base de conhecimento da Dra. Izabel, com o vetor usado na busca (RAG).

## Atributos

| Nome | Tipo | Obrigatório | Observação |
|------|------|-------------|------------|
| id | UUID | sim | PK |
| fonte | texto | sim | origem do trecho, ex.: capítulo do livro |
| conteudo | texto | sim |  |
| embedding | vetor(384) | sim | gte-small |
| created_at | timestamp | sim | |
| updated_at | timestamp | sim | |

## Invariantes / Regras

- Só o servidor (service_role) lê e grava; o app nunca acessa direto.
- Todo documento vem de material da Dra. Izabel.

## Relacionamentos

- Sem relacionamentos (catálogo independente).

## Usado em

- [Chat com IA](../features/chat-ia.md) — contexto das respostas
