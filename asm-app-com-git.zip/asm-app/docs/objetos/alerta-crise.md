# Objeto: Alerta de crise

## Responsabilidade

Registro de risco detectado pela assistente ou acionado pelo paciente, e de quem atendeu.

## Atributos

| Nome | Tipo | Obrigatório | Observação |
|------|------|-------------|------------|
| id | UUID | sim | PK |
| conversa_id | UUID | não | FK → [Conversa](conversa.md) — nulo se veio do botão |
| paciente_id | UUID | sim | FK → [Perfil](perfil.md) |
| origem | enum ia · botao | sim |  |
| nivel | enum | sim | escala PENDENTE (definir com a Dra. Izabel) |
| profissional_id | UUID | não | FK → [Profissional](profissional.md) — quem assumiu |
| status | enum aberto · em_atendimento · encerrado | sim |  |
| created_at | timestamp | sim | |
| updated_at | timestamp | sim | |

## Invariantes / Regras

- Todo alerta aberto precisa de resposta humana — nunca é encerrado automaticamente.
- Transições: `aberto → em_atendimento → encerrado`.

## Relacionamentos

- N:1 com [Perfil](perfil.md)
- N:1 com [Conversa](conversa.md)
- N:1 com [Profissional](profissional.md)

## Usado em

- [Detecção de crise](../features/deteccao-crise.md)
- [Emergência](../features/emergencia.md)
