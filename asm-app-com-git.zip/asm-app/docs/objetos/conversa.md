# Objeto: Conversa

## Responsabilidade

Uma sessão de chat do paciente — com a assistente ou, após emergência/crise, com um profissional.

## Atributos

| Nome | Tipo | Obrigatório | Observação |
|------|------|-------------|------------|
| id | UUID | sim | PK |
| usuario_id | UUID | sim | FK → [Perfil](perfil.md) |
| titulo | texto | não | gerado da primeira mensagem |
| created_at | timestamp | sim | |
| updated_at | timestamp | sim | |

## Invariantes / Regras

- Pertence a um único paciente; ninguém mais lê sem consentimento.
- Excluir a conversa exclui as mensagens (cascata).

## Relacionamentos

- N:1 com [Perfil](perfil.md)
- 1:N com [Mensagem](mensagem.md) (composição)

## Usado em

- [Chat com IA](../features/chat-ia.md) — unidade do histórico
- [Detecção de crise](../features/deteccao-crise.md) — onde o alerta nasce
