# Objeto: Consulta

## Responsabilidade

Atendimento agendado entre paciente e profissional.

## Atributos

| Nome | Tipo | Obrigatório | Observação |
|------|------|-------------|------------|
| id | UUID | sim | PK |
| paciente_id | UUID | sim | FK → [Perfil](perfil.md) |
| profissional_id | UUID | sim | FK → [Profissional](profissional.md) |
| inicio_em | timestamp | sim | UTC |
| duracao_min | inteiro | sim |  |
| status | enum | sim | ver transições |
| link_chamada | texto | não | ferramenta de vídeo PENDENTE |
| created_at | timestamp | sim | |
| updated_at | timestamp | sim | |

## Invariantes / Regras

- Um profissional não tem duas consultas no mesmo horário.
- Transições de status válidas:
  - `agendada → confirmada` (profissional/sistema confirma)
  - `agendada|confirmada → cancelada` (paciente ou profissional)
  - `confirmada → realizada` (após o horário)

## Relacionamentos

- N:1 com [Perfil](perfil.md)
- N:1 com [Profissional](profissional.md)

## Usado em

- [Agendamento](../features/agendamento.md)
- [Relatório do paciente](../features/relatorio-paciente.md) — o relatório é gerado para uma consulta
