# Objeto: Perfil

## Responsabilidade

O paciente: dados de conta, plano e consentimento. 1:1 com o usuário do Supabase Auth (o `id` é o mesmo).

## Atributos

| Nome | Tipo | Obrigatório | Observação |
|------|------|-------------|------------|
| id | UUID | sim | PK |
| nome | texto | sim |  |
| plano | enum free · basic · premium | sim | padrão free — ver [regras](../regras.md) |
| consentimento_ia_em | timestamp | não | nulo = não pode conversar com a IA (LGPD) |
| created_at | timestamp | sim | |
| updated_at | timestamp | sim | |

## Invariantes / Regras

- Sem `consentimento_ia_em`, nenhuma conversa com a assistente é criada.
- Paciente só lê e edita o próprio perfil (RLS).

## Relacionamentos

- 1:N com [Conversa](conversa.md)
- 1:N com [Consulta](consulta.md)

## Usado em

- [Autenticação](../features/autenticacao.md) — criado no cadastro
- [Chat com IA](../features/chat-ia.md) — dono das conversas
