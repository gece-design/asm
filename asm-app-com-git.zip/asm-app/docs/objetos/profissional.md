# Objeto: Profissional

## Responsabilidade

Psicólogo(a) ou especialista que atende consultas e plantão pela ASM.

## Atributos

| Nome | Tipo | Obrigatório | Observação |
|------|------|-------------|------------|
| id | UUID | sim | PK |
| nome | texto | sim |  |
| registro_profissional | texto | sim | CRP ou equivalente |
| especialidade | texto | sim |  |
| foto_url | texto | não |  |
| atende_plantao | booleano | sim | entra na escala de emergência |
| created_at | timestamp | sim | |
| updated_at | timestamp | sim | |

## Invariantes / Regras

- Só aparece para pacientes com cadastro aprovado pela ASM.
- Regra de quem pode se cadastrar: PENDENTE (ver [regras](../regras.md)).

## Relacionamentos

- 1:N com [Consulta](consulta.md)
- 1:N com [Alerta de crise](alerta-crise.md) (quem assumiu)

## Usado em

- [Agendamento](../features/agendamento.md) — escolhido pelo paciente
- [Emergência](../features/emergencia.md) — atende o plantão
