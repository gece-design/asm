# Objetos do domínio

Cada arquivo descreve uma entidade: atributos, invariantes, relacionamentos e
onde é usada. **Os atributos vivem aqui e em mais lugar nenhum** — os outros
documentos linkam para cá.

## Inventário

<!-- kfe:index:start -->
| Arquivo | Responsabilidade |
|---------|------------------|
| [alerta-crise.md](alerta-crise.md) | Registro de risco detectado pela assistente ou acionado pelo paciente, e de quem atendeu. |
| [consulta.md](consulta.md) | Atendimento agendado entre paciente e profissional. |
| [conversa.md](conversa.md) | Uma sessão de chat do paciente — com a assistente ou, após emergência/crise, com um profissional. |
| [documento.md](documento.md) | Trecho da base de conhecimento da Dra. Izabel, com o vetor usado na busca (RAG). |
| [mensagem.md](mensagem.md) | Uma fala dentro da conversa. |
| [perfil.md](perfil.md) | O paciente: dados de conta, plano e consentimento. 1:1 com o usuário do Supabase Auth (o `id` é o mesmo). |
| [profissional.md](profissional.md) | Psicólogo(a) ou especialista que atende consultas e plantão pela ASM. |
<!-- kfe:index:end -->

## Relacionamentos

```
<Entidade> (1) ──< <Entidade>     (<cardinalidade em uma linha>)
```

## Convenções comuns a TODOS os objetos

- **PK**: `id` (<UUID>).
- **Timestamps**: `created_at`, `updated_at`<, `deleted_at?` (soft delete)>.
- **Audit mínimo**: `created_by` quando aplicável.

Persistência é decisão do back: [../03-contrato-api.md](../03-contrato-api.md).

## Como adicionar um objeto

Arquivo novo a partir do template do kit (`templates/docs/objetos/objeto.md`), com
TODAS as seções obrigatórias. Depois: `node .kfe/scripts/kfe-docs.mjs index`.
