# Objeto: Mensagem

## Responsabilidade

Uma fala dentro da conversa.

## Atributos

| Nome | Tipo | Obrigatório | Observação |
|------|------|-------------|------------|
| id | UUID | sim | PK |
| conversa_id | UUID | sim | FK → [Conversa](conversa.md) |
| autor | enum paciente · ia · profissional | sim |  |
| conteudo | texto | sim | dado sensível — nunca em log |
| created_at | timestamp | sim | |
| updated_at | timestamp | sim | |

## Invariantes / Regras

- Imutável depois de gravada.
- `autor = profissional` só existe em conversa assumida por profissional.

## Relacionamentos

- N:1 com [Conversa](conversa.md)

## Usado em

- [Chat com IA](../features/chat-ia.md)
- [Relatório do paciente](../features/relatorio-paciente.md) — matéria-prima do resumo
