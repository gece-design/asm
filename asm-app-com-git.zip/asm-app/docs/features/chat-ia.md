# Feature: Chat com IA

## Objetivo

Dar ao paciente apoio emocional a qualquer hora, com a voz e a metodologia da Dra. Izabel.

## Atores

- Paciente — conversa com a assistente
- Assistente — responde com base na base de conhecimento

## Pré-condições

- Paciente autenticado com consentimento de IA registrado (na fase de mocks: nenhuma).

## Fluxo principal

```
1. Paciente abre o app e cai no chat.
2. Escreve uma mensagem e envia.
3. A assistente responde em streaming (texto aparece aos poucos).
4. A conversa entra no histórico (/chats).
```

## Estados e exceções

| Estado | Quando | O que o usuário vê |
|--------|--------|--------------------|
| vazio | conversa nova | saudação + convite para contar como está |
| carregando | resposta em curso | texto aparecendo aos poucos |
| erro | falha de rede/servidor | mensagem de erro em PT + tentar de novo |
| limite | plano Free esgotado (429) | aviso do limite + oferta de plano |

## Regras de negócio

- Regras da IA: [regras.md](../regras.md#ia).
- Sinal de risco dispara a [Detecção de crise](deteccao-crise.md).

## Objetos envolvidos

- [Conversa](../objetos/conversa.md) — sessão
- [Mensagem](../objetos/mensagem.md) — cada fala
- [Documento](../objetos/documento.md) — contexto da resposta

## Componentes envolvidos

- [Catálogo de componentes](../componentes/README.md) — herdados do template (conversa, mensagem, campo de mensagem, markdown); fichas geradas no lote de UI.

## Rotas/telas

| Rota | Tela | Acesso |
|------|------|--------|
| `/` | Chat principal | autenticado |
| `/chats` | Histórico | autenticado |

Mapa completo: [../04-navegacao.md](../04-navegacao.md).

## Contratos consumidos

- [`IChatSource`](../05-contratos.md#ichatsource)
- Endpoints: `POST /functions/v1/chat` — padrões em [../03-contrato-api.md](../03-contrato-api.md)
