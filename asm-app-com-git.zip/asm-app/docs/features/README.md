# Features

Cada arquivo descreve uma feature (caso de uso / área) seguindo o template
fixo do kit. Teste de granularidade: **a feature cabe inteira num prompt
junto com o código da área?** Se não cabe, divida.

## Inventário

<!-- kfe:index:start -->
| Arquivo | Responsabilidade |
|---------|------------------|
| [agendamento.md](agendamento.md) | Levar o paciente da conversa com a IA a uma consulta marcada com um profissional real. |
| [autenticacao.md](autenticacao.md) | Criar a conta do paciente com segurança e registrar o consentimento exigido pela LGPD. |
| [chat-ia.md](chat-ia.md) | Dar ao paciente apoio emocional a qualquer hora, com a voz e a metodologia da Dra. Izabel. |
| [deteccao-crise.md](deteccao-crise.md) | Identificar risco à vida na conversa e colocar um humano no atendimento. |
| [emergencia.md](emergencia.md) | Conectar o paciente a um profissional humano imediatamente, com um toque. |
| [relatorio-paciente.md](relatorio-paciente.md) | Dar ao profissional o contexto do paciente antes da consulta. |
<!-- kfe:index:end -->

## Regras

- Feature descreve o que ACONTECE com o objeto; o que o objeto TEM mora em
  [../objetos/](../objetos/).
- Feature nova = arquivo novo. Nunca anexe no fim de outra "porque é pequena".
- Toda feature lista os objetos e os componentes que toca — é isso que deixa
  a IA carregar só o necessário.

## Como adicionar uma feature

Arquivo novo a partir do template do kit (`templates/docs/features/feature.md`), com
TODAS as seções obrigatórias. Depois: `node .kfe/scripts/kfe-docs.mjs index`.
