# Feature: Detecção de crise

## Objetivo

Identificar risco à vida na conversa e colocar um humano no atendimento.

## Atores

- Assistente — identifica o risco
- Profissional de plantão — assume o chat

## Pré-condições

- Chat com IA funcionando.
- Plantão definido (mesma pendência da [Emergência](emergencia.md)).

## Fluxo principal

```
1. A mensagem do paciente é avaliada antes da resposta.
2. Risco identificado: a assistente acolhe e informa CVV 188 / SAMU 192.
3. O sistema registra um alerta e chama o plantão.
4. O profissional assume a mesma conversa.
```

## Estados e exceções

| Estado | Quando | O que o usuário vê |
|--------|--------|--------------------|
| falso positivo | risco sinalizado sem motivo | acolhimento normal; profissional encerra o alerta |
| sem plantão | nenhum profissional disponível | CVV 188 e SAMU 192 em destaque |

## Regras de negócio

- Na dúvida, a assistente trata como risco.
- Critérios e níveis de risco: PENDENTE — definir com a Dra. Izabel, nunca inventados.

## Objetos envolvidos

- [Alerta de crise](../objetos/alerta-crise.md) — origem `ia`
- [Conversa](../objetos/conversa.md)
- [Mensagem](../objetos/mensagem.md)

## Componentes envolvidos

- [Catálogo de componentes](../componentes/README.md) — definidos no lote de UI a partir do Figma.

## Rotas/telas

| Rota | Tela | Acesso |
|------|------|--------|
| `/` | Chat principal | autenticado |

Mapa completo: [../04-navegacao.md](../04-navegacao.md).

## Contratos consumidos

- Endpoints: dentro de `POST /functions/v1/chat` — ver [../03-contrato-api.md](../03-contrato-api.md)
