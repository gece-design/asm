# Feature: Autenticação

## Objetivo

Criar a conta do paciente com segurança e registrar o consentimento exigido pela LGPD.

## Atores

- Paciente — cria conta, entra, sai

## Pré-condições

- Nenhuma.

## Fluxo principal

```
1. Paciente vê o onboarding.
2. Cria conta (e-mail + senha).
3. Aceita o termo de consentimento de uso da IA.
4. Cai no chat.
```

## Estados e exceções

| Estado | Quando | O que o usuário vê |
|--------|--------|--------------------|
| erro | e-mail já usado / senha fraca | mensagem no campo |
| sessão expirada | token vencido | volta ao login preservando o destino |

## Regras de negócio

- Sem consentimento, sem conversa com a IA.
- Login com Google: opcional, fora da v1 até decisão.

## Objetos envolvidos

- [Perfil](../objetos/perfil.md)

## Componentes envolvidos

- [Catálogo de componentes](../componentes/README.md) — definidos no lote de UI a partir do Figma.

## Rotas/telas

| Rota | Tela | Acesso |
|------|------|--------|
| `/entrar` | Login | público |
| `/cadastro` | Cadastro | público |
| `/(settings)/profile` | Perfil | autenticado |

Mapa completo: [../04-navegacao.md](../04-navegacao.md).

## Contratos consumidos

- SDK `@supabase/supabase-js` (Auth) — ver [../03-contrato-api.md](../03-contrato-api.md)
