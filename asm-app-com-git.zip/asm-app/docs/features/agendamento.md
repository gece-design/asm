# Feature: Agendamento

## Objetivo

Levar o paciente da conversa com a IA a uma consulta marcada com um profissional real.

## Atores

- Paciente — escolhe profissional e horário
- Profissional — recebe a consulta

## Pré-condições

- Paciente autenticado.
- Profissionais cadastrados com agenda disponível.

## Fluxo principal

```
1. No chat, o paciente pede (ou a IA sugere) falar com um profissional.
2. A IA mostra profissionais disponíveis dentro do chat.
3. Paciente abre o detalhe e escolhe um horário.
4. Confirma e vê a tela de confirmação com data, hora e link.
```

## Estados e exceções

| Estado | Quando | O que o usuário vê |
|--------|--------|--------------------|
| vazio | sem horário disponível | aviso + opção de outro profissional |
| carregando | buscando agenda | skeleton dos cards |
| erro | horário ocupado na hora de confirmar | aviso + voltar aos horários |

## Regras de negócio

- Um profissional não tem duas consultas no mesmo horário.
- Valor: consulta R$ 150/h — ver [regras.md](../regras.md#planos-e-cobrança).
- Ferramenta de videochamada: PENDENTE.

## Objetos envolvidos

- [Profissional](../objetos/profissional.md)
- [Consulta](../objetos/consulta.md)

## Componentes envolvidos

- [Catálogo de componentes](../componentes/README.md) — definidos no lote de UI a partir do Figma.

## Rotas/telas

| Rota | Tela | Acesso |
|------|------|--------|
| `/profissionais/[id]` | Detalhe do profissional | autenticado |
| `/consulta/[id]` | Confirmação | autenticado |

Mapa completo: [../04-navegacao.md](../04-navegacao.md).

## Contratos consumidos

- Endpoints: PENDENTE (definidos na etapa UX) — padrões em [../03-contrato-api.md](../03-contrato-api.md)
