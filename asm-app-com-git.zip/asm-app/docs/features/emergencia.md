# Feature: Emergência

## Objetivo

Conectar o paciente a um profissional humano imediatamente, com um toque.

## Atores

- Paciente — aciona
- Profissional de plantão — atende

## Pré-condições

- **Plantão definido (quem e em que horário). Sem isso a feature não vai ao ar.**

## Fluxo principal

```
1. Paciente toca no botão de emergência (visível no chat).
2. O app registra o alerta e busca profissional de plantão.
3. Profissional assume o atendimento.
```

## Estados e exceções

| Estado | Quando | O que o usuário vê |
|--------|--------|--------------------|
| sem plantão | nenhum profissional disponível | CVV 188 e SAMU 192 em destaque, com ligação direta |
| carregando | procurando profissional | aviso calmo de que alguém está sendo chamado |
| erro | falha de rede | CVV 188 e SAMU 192 em destaque |

## Regras de negócio

- O botão nunca fica escondido atrás de menu.
- Falha técnica nunca deixa o paciente sem um número para ligar.

## Objetos envolvidos

- [Alerta de crise](../objetos/alerta-crise.md) — origem `botao`
- [Profissional](../objetos/profissional.md) — plantão

## Componentes envolvidos

- [Catálogo de componentes](../componentes/README.md) — definidos no lote de UI a partir do Figma.

## Rotas/telas

| Rota | Tela | Acesso |
|------|------|--------|
| `/emergencia` | Emergência | autenticado |

Mapa completo: [../04-navegacao.md](../04-navegacao.md).

## Contratos consumidos

- Endpoints: PENDENTE — padrões em [../03-contrato-api.md](../03-contrato-api.md)
