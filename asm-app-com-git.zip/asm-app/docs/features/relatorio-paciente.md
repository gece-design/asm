# Feature: Relatório do paciente

## Objetivo

Dar ao profissional o contexto do paciente antes da consulta.

## Atores

- Profissional — lê antes da consulta
- Paciente — acesso PENDENTE

## Pré-condições

- Consulta agendada.
- Consentimento do paciente para compartilhar o resumo.

## Fluxo principal

```
1. Antes da consulta, o sistema gera um resumo das conversas recentes.
2. O profissional abre o relatório vinculado à consulta.
```

## Estados e exceções

| Estado | Quando | O que o usuário vê |
|--------|--------|--------------------|
| vazio | paciente sem conversas | relatório indica que não há histórico |
| erro | falha ao gerar | profissional atende sem relatório; aviso discreto |

## Regras de negócio

- O relatório não contém diagnóstico.
- Quem acessa: PENDENTE (ver [regras.md](../regras.md)).

## Objetos envolvidos

- [Consulta](../objetos/consulta.md)
- [Conversa](../objetos/conversa.md)
- [Mensagem](../objetos/mensagem.md)

## Componentes envolvidos

- [Catálogo de componentes](../componentes/README.md) — definidos no lote de UI a partir do Figma.

## Rotas/telas

| Rota | Tela | Acesso |
|------|------|--------|
| PENDENTE | Relatório | profissional |

Mapa completo: [../04-navegacao.md](../04-navegacao.md).

## Contratos consumidos

- Endpoints: PENDENTE — padrões em [../03-contrato-api.md](../03-contrato-api.md)
