# Avisos de terceiros

## EvanBacon/chat-template

Base de código do app (fork do commit 40379fcbc8d57025e09eef77ae129b7b30b100c7).
Origem: https://github.com/EvanBacon/chat-template

Declaração de licença do autor (README do repositório original):
"This template was made for https://agent.expo.dev and is made freely
available under the MIT license."

MIT License

Copyright (c) Evan Bacon

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## Montserrat

Fonte em `assets/fonts/`. Copyright The Montserrat Project Authors.
SIL Open Font License 1.1 — https://openfontlicense.org
