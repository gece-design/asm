// Tipagem mínima do runtime de IA do Supabase Edge (embeddings gte-small).
declare const Supabase: {
  ai: {
    Session: new (model: "gte-small") => {
      run(input: string, opts: { mean_pool: boolean; normalize: boolean }): Promise<number[]>;
    };
  };
};
