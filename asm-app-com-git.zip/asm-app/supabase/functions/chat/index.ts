// Edge Function `chat` — ASM
// RASCUNHO DA FASE 2 (back-end). Contrato: docs/03-contrato-api.md.
//
// Fluxo: mensagens do app → embedding da última fala → busca na base da
// Dra. Izabel (pgvector) → Claude com o prompt da ASM → streaming no
// formato UI Message Stream do AI SDK (o que o useChat do app espera).
//
// Secrets: supabase secrets set ANTHROPIC_API_KEY=... [ASM_CHAT_MODEL=...]
// Deploy:  supabase functions deploy chat

/// <reference path="./supabase-ai.d.ts" />
import { createAnthropic } from "@ai-sdk/anthropic";
import { convertToModelMessages, streamText, type UIMessage } from "ai";
import { createClient } from "@supabase/supabase-js";
import { buildSystemPrompt } from "./prompt.ts";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const anthropic = createAnthropic({ apiKey: Deno.env.get("ANTHROPIC_API_KEY") });
// Modelo por secret, para trocar sem novo deploy. Padrão: Sonnet (tom e segurança).
const MODEL = Deno.env.get("ASM_CHAT_MODEL") ?? "claude-sonnet-5-5";

// Embeddings gratuitos no próprio runtime do Supabase (gte-small, 384 dimensões).
const embedder = new Supabase.ai.Session("gte-small");

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

function ultimaFalaDoUsuario(messages: UIMessage[]): string {
  const ultima = [...messages].reverse().find((m) => m.role === "user");
  if (!ultima) return "";
  return ultima.parts
    .map((p) => (p.type === "text" ? p.text : ""))
    .join(" ")
    .trim();
}

async function buscarConhecimento(texto: string): Promise<string[]> {
  if (!texto) return [];
  const embedding = await embedder.run(texto, { mean_pool: true, normalize: true });
  const { data, error } = await supabase.rpc("buscar_documentos", {
    consulta_embedding: embedding,
    limiar: 0.78,
    quantidade: 5,
  });
  if (error) {
    console.error("RAG:", error.message); // só a mensagem de erro — nunca o texto do paciente
    return []; // sem contexto a IA ainda responde — nunca derruba o chat
  }
  return (data ?? []).map((d: { conteudo: string }) => d.conteudo);
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") {
    return Response.json(
      { data: null, meta: {}, errors: [{ code: "metodo_invalido" }] },
      { status: 405, headers: CORS },
    );
  }

  const { messages } = (await req.json()) as { messages: UIMessage[] };

  // TODO(feature detecção de crise — docs/features/deteccao-crise.md):
  // classificar risco ANTES da resposta, registrar alerta_crise e acionar
  // o plantão. Lote dos meses 4–5 do contrato.

  const conhecimento = await buscarConhecimento(ultimaFalaDoUsuario(messages));

  const result = streamText({
    model: anthropic(MODEL),
    system: buildSystemPrompt(conhecimento),
    messages: await convertToModelMessages(messages),
  });

  return result.toUIMessageStreamResponse({
    headers: {
      ...CORS,
      // iOS (NSURLSession) só faz streaming com esses dois cabeçalhos.
      "Content-Type": "application/octet-stream",
      "Content-Encoding": "none",
    },
  });
});
