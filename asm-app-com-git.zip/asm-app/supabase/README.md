# supabase/ — back-end do ASM (Fase 2)

**Rascunho.** Pela regra do Kill Front-End, o front nasce 100% sobre mocks e o
back é implementado depois, contra o contrato em `docs/03-contrato-api.md`.
Estes arquivos existem para o contrato não ser abstrato — não foram aplicados.

| Arquivo | O quê |
|---|---|
| `functions/chat/` | Edge Function do chat: RAG (pgvector + gte-small) + Claude em streaming |
| `migrations/…_base_chat_rag.sql` | perfis, conversas, mensagens, documentos + RLS |

Ligar o app na IA real: `supabase functions deploy chat`, preencher
`EXPO_PUBLIC_CHAT_URL` e trocar `EXPO_PUBLIC_MOCK_AI=0`.
