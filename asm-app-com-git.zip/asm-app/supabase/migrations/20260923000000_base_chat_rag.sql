-- ASM · migração base — RASCUNHO DA FASE 2 (não aplicada)
-- Cobre chat + base de conhecimento. Agendamento, emergência e relatório
-- entram em migrações próprias, a partir de docs/objetos/.
-- Idioma dos campos: PT, snake_case (docs/03-contrato-api.md).

create extension if not exists vector;

-- Perfil do paciente (1:1 com auth.users)
create table public.perfis (
  id uuid primary key references auth.users (id) on delete cascade,
  nome text not null,
  plano text not null default 'free' check (plano in ('free', 'basic', 'premium')),
  consentimento_ia_em timestamptz,          -- LGPD: aceite explícito
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.conversas (
  id uuid primary key default gen_random_uuid(),
  usuario_id uuid not null references public.perfis (id) on delete cascade,
  titulo text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.mensagens (
  id uuid primary key default gen_random_uuid(),
  conversa_id uuid not null references public.conversas (id) on delete cascade,
  autor text not null check (autor in ('paciente', 'ia', 'profissional')),
  conteudo text not null,
  created_at timestamptz not null default now()
);
create index on public.mensagens (conversa_id, created_at);

-- Base de conhecimento da Dra. Izabel (somente leitura para o app)
create table public.documentos (
  id uuid primary key default gen_random_uuid(),
  fonte text not null,                      -- ex.: "livro-cap-3", "protocolo-ansiedade"
  conteudo text not null,
  embedding vector(384) not null,           -- gte-small
  created_at timestamptz not null default now()
);
create index on public.documentos using hnsw (embedding vector_cosine_ops);

create or replace function public.buscar_documentos (
  consulta_embedding vector(384),
  limiar float,
  quantidade int
) returns table (id uuid, fonte text, conteudo text, similaridade float)
language sql stable as $$
  select d.id, d.fonte, d.conteudo, 1 - (d.embedding <=> consulta_embedding) as similaridade
  from public.documentos d
  where 1 - (d.embedding <=> consulta_embedding) > limiar
  order by d.embedding <=> consulta_embedding
  limit quantidade;
$$;

-- RLS: cada paciente só enxerga o que é seu
alter table public.perfis enable row level security;
alter table public.conversas enable row level security;
alter table public.mensagens enable row level security;
alter table public.documentos enable row level security;

create policy "perfil próprio" on public.perfis
  for all using (auth.uid() = id) with check (auth.uid() = id);

create policy "conversas próprias" on public.conversas
  for all using (auth.uid() = usuario_id) with check (auth.uid() = usuario_id);

create policy "mensagens das próprias conversas" on public.mensagens
  for all using (
    exists (select 1 from public.conversas c
            where c.id = conversa_id and c.usuario_id = auth.uid())
  ) with check (
    exists (select 1 from public.conversas c
            where c.id = conversa_id and c.usuario_id = auth.uid())
  );
-- documentos: sem policy = só service_role (Edge Function) acessa.
